nptash-template/
├── index.html              # صفحه اصلی
├── products.html           # صفحه محصولات
├── about.html              # درباره ما
├── contact.html            # تماس با ما
├── assets/                 
│   ├── css/
│   │   ├── main.css        # استایل اصلی
│   │   └── rtl.css         # پشتیبانی کامل از راست‌چین
│   ├── js/
│   │   └── scripts.js      # اسکریپت‌های تعاملی
│   └── images/             # تصاویر دمو (قابل جایگزینی)
├── admin/                  # پنل مدیریت Decap CMS
│   ├── index.html
│   └── config.yml          
├── vercel.json             # تنظیمات اختصاصی Vercel
└── README.txt              # راهنمای نصب و ویرایش